const unlock=new Date('2026-07-24T14:30:00');
const c=document.getElementById('countdown');
function tick(){
 const d=unlock-new Date();
 if(d<=0){start();return;}
 const s=Math.floor(d/1000),dd=Math.floor(s/86400),hh=Math.floor(s%86400/3600),mm=Math.floor(s%3600/60),ss=s%60;
 c.textContent=`${dd}d ${hh}h ${mm}m ${ss}s`;
}
let started=false;
async function wait(ms){return new Promise(r=>setTimeout(r,ms))}
async function start(){
 if(started)return;started=true;
 document.getElementById('countdown').style.display='none';
 const st=document.getElementById('status');
 for(const t of ['Searching destination...','Loading itinerary...','Resolving route...']){
   st.textContent=t; await wait(7000);
 }
 const dst=document.getElementById('destination');
 dst.textContent='';
 for(const ch of 'FRANCE'){dst.textContent+=ch;await wait(180);}
 document.getElementById('routes').style.display='block';
 await wait(7000);
 document.querySelector('.board').style.display='none';
 document.getElementById('final').style.display='block';
}
tick();setInterval(tick,1000);